'''Given two text files that have lists of numbers in them, import both files
and test for overlap in the two lists, returning the resulting list'''

def main():
    try:
        with open("primenumbers.txt") as primes:
            prime_list = [x.rstrip() for x in primes]
        with open("happynumbers.txt") as happies:
            happies_list = [x.rstrip() for x in happies]

        overlap_list = []

        for num in prime_list:
            for numby in happies_list:
                if num == numby:
                    overlap_list.append(num)
        print(*overlap_list, sep=", ")
    except:
        print("I don't know how there could be an exception thrown, but it has happened.")
        
if __name__ == '__main__':
    main()
